<?php
//initialize facebook sdk
require 'vendor/autoload.php';
session_start();
$fb = new Facebook\Facebook([
    'app_id' => '275144075021685', // your app id
    'app_secret' => 'bd0cd6a58d66e2e2667f258e6cfc9e14', // your app secret
    'default_graph_version' => 'v2.5',
]);
$helper = $fb->getRedirectLoginHelper();
$permissions = ['email']; // optional
try {
    if (isset($_SESSION['facebook_access_token'])) {
        $accessToken = $_SESSION['facebook_access_token'];
    } else {
        $accessToken = $helper->getAccessToken();
    }
} catch (Facebook\Exceptions\facebookResponseException $e) {
    // When Graph returns an error
    echo 'Graph returned an error: ' . $e->getMessage();
    exit;
} catch (Facebook\Exceptions\FacebookSDKException $e) {
    // When validation fails or other local issues
    echo 'Facebook SDK returned an error: ' . $e->getMessage();
    exit;
}
if (isset($accessToken)) {
    if (isset($_SESSION['facebook_access_token'])) {
        $fb->setDefaultAccessToken($_SESSION['facebook_access_token']);
    } else {
        // getting short-lived access token
        $_SESSION['facebook_access_token'] = (string) $accessToken;
        // OAuth 2.0 client handler
        $oAuth2Client = $fb->getOAuth2Client();
        // Exchanges a short-lived access token for a long-lived one
        $longLivedAccessToken = $oAuth2Client->getLongLivedAccessToken($_SESSION['facebook_access_token']);
        $_SESSION['facebook_access_token'] = (string) $longLivedAccessToken;
        // setting default access token to be used in script
        $fb->setDefaultAccessToken($_SESSION['facebook_access_token']);
    }
    // redirect the user to the profile page if it has "code" GET variable
    if (isset($_GET['code'])) {
        header('Location: profile.php');
    }
    // getting basic info about user
    try {
        $profile_request = $fb->get('/me?fields=name,first_name,last_name,email,picture.width(200)');
        $profile = $profile_request->getGraphUser();
        $fbid = $profile->getId();           // To Get Facebook ID
        $fbfullname = $profile->getName();   // To Get Facebook full name
        $fbemail = $profile->getEmail();    // To Get Facebook email
    
        // Getting the profile picture URL
        $fbpic = $profile->getPicture()->getUrl();
    
        # save the user information in session variable
        $_SESSION['fb_id'] = $fbid . '</br>';
        $_SESSION['fb_name'] = $fbfullname . '</br>';
        $_SESSION['fb_email'] = $fbemail . '</br>';
        $_SESSION['fb_pic'] = $fbpic;
    
    } catch (Facebook\Exceptions\FacebookResponseException $e) {
        // When Graph returns an error
        echo 'Graph returned an error: ' . $e->getMessage();
        session_destroy();
        // redirecting user back to app login page
        header("Location: ./");
        exit;
    } catch (Facebook\Exceptions\FacebookSDKException $e) {
        // When validation fails or other local issues
        echo 'Facebook SDK returned an error: ' . $e->getMessage();
        exit;
    }
    
} else {
    // replace  website URL same as added in the developers.Facebook.com/apps e.g. if you used http instead of https and used            
    $loginUrl = $helper->getLoginUrl('http://localhost/flogincheck/', $permissions);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CUKKO-Whatsapp Business API</title>
    <link rel="stylesheet" href="css/auth.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    <div id="main">
        <div class="signup-container">
            <div class="logo"><img src="images/logo.jpg"></div>
            <div class="form-box">
                <form method="post">
                    <div class="top">
                        <div class="login-with">Login With</div>
                        <div class="buttons">
                            <a class="btn btn-primary py-2" href="<?php echo htmlspecialchars($loginUrl); ?>">
                                <i class="fa-brands fa-facebook-f"></i>&nbsp;&nbsp;&nbsp;Facebook
                            </a>

                            <a class="btn btn-success py-2" href="#"><i class="fa-brands fa-google"></i>&nbsp;&nbsp;&nbsp;Google</a>
                        </div>
                        <div class="pt-2">Or Use Email</div>
                    </div>
                    <label for="name">Name</label>
                    <input type="text" name="name" id="name">
                    <label for="email">Email</label>
                    <input type="email" name="email" id="email">
                    <label for="password">Password</label>
                    <input type="password" name="password">
                    <label for="cpassword">Confirm Password</label>
                    <input type="password" name="password_confirmation" id="password_confirmation">
                    <div class="bottom">
                        <a href="login.php">Already Registered?</a>
                        <button type="submit">REGISTER</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>

</html>