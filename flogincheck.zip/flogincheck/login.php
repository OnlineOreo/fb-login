<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CUKKO-Whatsapp Business api</title>
    <link rel="stylesheet" href="css/auth.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"
        integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>
    <div id="main">
        <div class="signup-container">
            <div class="logo"><img src="images/logo.jpg"></div>
            <div class="form-box">
                <form method="post">
                    <div class="top">
                        <div class="login-with">login With</div>
                        <div class="buttons">
                            <button><i class="fa-brands fa-facebook-f"></i>&nbsp;&nbsp;&nbsp;Facebook</button>
                            <button><i class="fa-brands fa-google"></i>&nbsp;&nbsp;&nbsp;Google</button>
                        </div>
                        <div>Or Use Email</div>
                    </div>
                    <label>Email</label>
                    <input type="text" name="email">
                    <label>Password</label>
                    <input type="text" name="password">
                    <div class="bottom">
                        <a href="#">Forgot Your Password?</a>
                        <button type="submit">LOG IN</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>